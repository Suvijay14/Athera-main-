#!/bin/bash
set -euo pipefail

AGENT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$AGENT_DIR"
export OLLAMA_MODEL="${OLLAMA_MODEL:-llama3.1:8b}"

if curl -sf http://localhost:3002/health >/dev/null 2>&1; then
  echo "Agent already running on 3002"
  exit 0
fi

nohup npm run start >>/tmp/athena-agent.log 2>&1 &
sleep 2

if curl -sf http://localhost:3002/health >/dev/null 2>&1; then
  echo "Agent started on 3002"
else
  echo "Agent may still be starting — check /tmp/athena-agent.log"
fi
