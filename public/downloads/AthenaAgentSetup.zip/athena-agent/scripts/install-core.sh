#!/bin/bash
# Core install — no UI. Called by Athena Setup.app or install.sh
set -euo pipefail

AGENT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$AGENT_DIR"
LOG="/tmp/athena-agent-setup.log"
exec > >(tee -a "$LOG") 2>&1

echo "==> Athena Agent setup @ $AGENT_DIR"

if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: Node.js not found"
  exit 2
fi

echo "==> npm install..."
npm install --silent

OLLAMA_BIN=""
for candidate in /usr/local/bin/ollama /opt/homebrew/bin/ollama; do
  if [ -x "$candidate" ]; then OLLAMA_BIN="$candidate"; break; fi
done

if [ -z "$OLLAMA_BIN" ] && [ -d "/Applications/Ollama.app" ]; then
  open -a Ollama
  sleep 4
  for candidate in /usr/local/bin/ollama /opt/homebrew/bin/ollama; do
    if [ -x "$candidate" ]; then OLLAMA_BIN="$candidate"; break; fi
  done
fi

if [ -n "$OLLAMA_BIN" ]; then
  if ! curl -sf http://localhost:11434/api/tags >/dev/null 2>&1; then
    echo "==> Starting ollama serve..."
    nohup "$OLLAMA_BIN" serve >>/tmp/athena-ollama.log 2>&1 &
    sleep 3
  fi
  MODEL="${OLLAMA_MODEL:-llama3.1:8b}"
  echo "==> Pulling $MODEL..."
  "$OLLAMA_BIN" pull "$MODEL" || echo "WARN: model pull failed"
else
  echo "WARN: Ollama not installed"
  exit 3
fi

echo "==> Core install done"
