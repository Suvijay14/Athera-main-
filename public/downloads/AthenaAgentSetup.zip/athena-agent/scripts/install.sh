#!/bin/bash
# Terminal fallback — prefer double-clicking "Athena Setup.app"
set -euo pipefail

AGENT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
bash "$AGENT_DIR/scripts/install-core.sh"
bash "$AGENT_DIR/scripts/start-background.sh"
echo "Agent running at http://localhost:3002"
