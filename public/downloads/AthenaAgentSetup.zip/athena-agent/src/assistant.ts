import { chat } from './ollama.js'
import { runTool, TOOL_CATALOG } from './tools.js'

const SYSTEM = `You are Athena, a voice assistant on macOS. You help by taking actions on the user's computer.

${TOOL_CATALOG}

Rules:
- Reply with ONLY valid JSON, no markdown fences.
- To speak to the user: {"action":"respond","text":"your short spoken reply"}
- To use a tool: {"action":"tool","tool":"tool_name","params":{}}
- After tool results, decide next step (another tool or respond).
- Keep spoken replies under 2 sentences. Be direct.
- Never mention Dex or vault. You use local Ollama only.
- If you cannot do something, respond honestly.`

export interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
}

interface AgentAction {
  action: 'respond' | 'tool'
  text?: string
  tool?: string
  params?: Record<string, unknown>
}

function parseAction(raw: string): AgentAction | null {
  const trimmed = raw.trim()
  const jsonMatch = trimmed.match(/\{[\s\S]*\}/)
  if (!jsonMatch) return null
  try {
    return JSON.parse(jsonMatch[0]) as AgentAction
  } catch {
    return null
  }
}

export async function runAssistant(
  userText: string,
  history: ChatMessage[] = []
): Promise<{ response: string; toolsUsed: string[] }> {
  const toolsUsed: string[] = []
  const messages: Array<{ role: string; content: string }> = [
    { role: 'system', content: SYSTEM },
    ...history.map((m) => ({ role: m.role, content: m.content })),
    { role: 'user', content: userText },
  ]

  for (let step = 0; step < 5; step++) {
    const raw = await chat(messages)
    const action = parseAction(raw)

    if (!action) {
      return { response: raw || 'I could not process that.', toolsUsed }
    }

    if (action.action === 'respond' && action.text) {
      return { response: action.text, toolsUsed }
    }

    if (action.action === 'tool' && action.tool) {
      toolsUsed.push(action.tool)
      const result = await runTool(action.tool, action.params ?? {})
      messages.push({ role: 'assistant', content: raw })
      messages.push({
        role: 'user',
        content: `Tool result for ${action.tool}: ${JSON.stringify(result)}`,
      })
      continue
    }

    return { response: 'Something went wrong.', toolsUsed }
  }

  return { response: 'I hit my step limit. Try a simpler request.', toolsUsed }
}
