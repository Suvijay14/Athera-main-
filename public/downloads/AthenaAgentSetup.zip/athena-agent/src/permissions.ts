import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import fs from 'node:fs/promises'
import path from 'node:path'
import os from 'node:os'

const exec = promisify(execFile)

export interface PermissionStatus {
  id: string
  label: string
  description: string
  granted: boolean | 'unknown'
  settingsUrl?: string
}

export async function checkPermissions(): Promise<PermissionStatus[]> {
  const [screenshot, files, automation] = await Promise.all([
    checkScreenshotPermission(),
    checkFilesPermission(),
    checkAutomationHint(),
  ])

  return [
    {
      id: 'microphone',
      label: 'Microphone',
      description: 'Granted in the browser when you tap the mic button.',
      granted: 'unknown',
    },
    screenshot,
    files,
    automation,
  ]
}

async function checkScreenshotPermission(): Promise<PermissionStatus> {
  let granted: boolean | 'unknown' = 'unknown'
  try {
    const tmp = path.join(os.tmpdir(), `athena-perm-test-${Date.now()}.png`)
    await exec('/usr/sbin/screencapture', ['-x', tmp])
    await fs.unlink(tmp).catch(() => {})
    granted = true
  } catch {
    granted = false
  }

  return {
    id: 'screen_recording',
    label: 'Screen Recording',
    description: 'Required for screenshots. System Settings → Privacy → Screen Recording.',
    granted,
    settingsUrl: 'x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture',
  }
}

async function checkFilesPermission(): Promise<PermissionStatus> {
  let granted = true
  try {
    await fs.readdir(os.homedir())
  } catch {
    granted = false
  }

  return {
    id: 'files',
    label: 'Files & Folders',
    description: 'Access Desktop, Documents, Downloads. May prompt on first use.',
    granted,
    settingsUrl: 'x-apple.systempreferences:com.apple.preference.security?Privacy_FilesAndFolders',
  }
}

async function checkAutomationHint(): Promise<PermissionStatus> {
  return {
    id: 'automation',
    label: 'Automation',
    description: 'Optional — for opening apps and Finder. Granted per-app when prompted.',
    granted: 'unknown',
    settingsUrl: 'x-apple.systempreferences:com.apple.preference.security?Privacy_Automation',
  }
}

export async function requestPermissionHints(): Promise<{ message: string; settings: string[] }> {
  const perms = await checkPermissions()
  const settings = perms
    .filter((p) => p.granted === false && p.settingsUrl)
    .map((p) => p.settingsUrl!) 

  return {
    message:
      'Grant permissions in System Settings when prompted. Screen Recording is required for screenshots.',
    settings,
  }
}
