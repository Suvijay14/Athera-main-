import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import fs from 'node:fs/promises'
import path from 'node:path'
import os from 'node:os'

const exec = promisify(execFile)

export interface ToolResult {
  success: boolean
  data?: unknown
  error?: string
}

export const TOOL_CATALOG = `
Available tools (return JSON to use one):
- take_screenshot: Capture the screen. params: {}
- list_files: List files in a folder. params: { "path": "~/Desktop" }
- read_file: Read a text file (max 8KB). params: { "path": "~/Documents/note.txt" }
- find_file: Search for files by name. params: { "name": "report", "directory": "~" }
- get_system_info: Mac system info. params: {}
- open_folder: Reveal folder in Finder. params: { "path": "~/Downloads" }
`.trim()

function expandHome(p: string): string {
  if (p.startsWith('~/')) return path.join(os.homedir(), p.slice(2))
  return p
}

function safePath(input: string): string | null {
  const resolved = path.resolve(expandHome(input))
  const home = os.homedir()
  if (!resolved.startsWith(home)) return null
  return resolved
}

export async function runTool(name: string, params: Record<string, unknown>): Promise<ToolResult> {
  try {
    switch (name) {
      case 'take_screenshot':
        return await takeScreenshot()
      case 'list_files':
        return await listFiles(String(params.path ?? '~/Desktop'))
      case 'read_file':
        return await readFile(String(params.path ?? ''))
      case 'find_file':
        return await findFile(String(params.name ?? ''), String(params.directory ?? '~'))
      case 'get_system_info':
        return getSystemInfo()
      case 'open_folder':
        return await openFolder(String(params.path ?? '~/Desktop'))
      default:
        return { success: false, error: `Unknown tool: ${name}` }
    }
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : 'Tool failed' }
  }
}

async function takeScreenshot(): Promise<ToolResult> {
  const dir = path.join(os.tmpdir(), 'athena-agent')
  await fs.mkdir(dir, { recursive: true })
  const out = path.join(dir, `screenshot-${Date.now()}.png`)
  await exec('/usr/sbin/screencapture', ['-x', out])
  return { success: true, data: { path: out, message: 'Screenshot saved' } }
}

async function listFiles(folder: string): Promise<ToolResult> {
  const resolved = safePath(folder)
  if (!resolved) return { success: false, error: 'Path must be inside your home directory' }

  const entries = await fs.readdir(resolved, { withFileTypes: true })
  const files = entries.slice(0, 50).map((e) => ({
    name: e.name,
    type: e.isDirectory() ? 'directory' : 'file',
  }))
  return { success: true, data: { path: resolved, files } }
}

async function readFile(filePath: string): Promise<ToolResult> {
  const resolved = safePath(filePath)
  if (!resolved) return { success: false, error: 'Path must be inside your home directory' }

  const stat = await fs.stat(resolved)
  if (!stat.isFile()) return { success: false, error: 'Not a file' }
  if (stat.size > 8192) return { success: false, error: 'File too large (max 8KB)' }

  const content = await fs.readFile(resolved, 'utf-8')
  return { success: true, data: { path: resolved, content } }
}

async function findFile(name: string, directory: string): Promise<ToolResult> {
  const resolved = safePath(directory)
  if (!resolved) return { success: false, error: 'Directory must be inside your home directory' }
  if (!name.trim()) return { success: false, error: 'name is required' }

  const query = "kMDItemDisplayName == '*" + name + "*'c"
  const { stdout } = await exec('mdfind', ['-onlyin', resolved, query])
  const matches = stdout
    .trim()
    .split('\n')
    .filter(Boolean)
    .slice(0, 20)
  return { success: true, data: { matches } }
}

function getSystemInfo(): ToolResult {
  return {
    success: true,
    data: {
      platform: process.platform,
      hostname: os.hostname(),
      homedir: os.homedir(),
      cpus: os.cpus().length,
      memoryGB: Math.round(os.totalmem() / 1024 / 1024 / 1024),
    },
  }
}

async function openFolder(folder: string): Promise<ToolResult> {
  const resolved = safePath(folder)
  if (!resolved) return { success: false, error: 'Path must be inside your home directory' }

  await exec('open', [resolved])
  return { success: true, data: { path: resolved, message: 'Opened in Finder' } }
}
