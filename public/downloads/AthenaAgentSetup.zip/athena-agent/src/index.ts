import express from 'express'
import cors from 'cors'
import { runAssistant } from './assistant.js'
import { checkPermissions, requestPermissionHints } from './permissions.js'
import { isRunning, listModels, pickBestModel, getModel } from './ollama.js'
import { runTool, TOOL_CATALOG } from './tools.js'

const PORT = Number(process.env.PORT || 3002)
const app = express()

app.use(
  cors({
    origin: ['http://localhost:3000', 'http://127.0.0.1:3000', process.env.FRONTEND_URL].filter(
      Boolean
    ) as string[],
  })
)
app.use(express.json({ limit: '2mb' }))

app.get('/health', async (_req, res) => {
  const ollama = await isRunning()
  const models = ollama ? await listModels() : []
  res.json({
    status: 'ok',
    ollama,
    model: getModel(),
    installedModels: models,
    suggestedModel: models.length ? pickBestModel(models) : getModel(),
    platform: process.platform,
  })
})

app.get('/permissions', async (_req, res) => {
  res.json({ permissions: await checkPermissions() })
})

app.post('/permissions/request', async (_req, res) => {
  res.json(await requestPermissionHints())
})

app.get('/tools', (_req, res) => {
  res.json({ catalog: TOOL_CATALOG })
})

app.post('/tools/run', async (req, res) => {
  const { tool, params } = req.body as { tool?: string; params?: Record<string, unknown> }
  if (!tool) return res.status(400).json({ error: 'tool is required' })
  const result = await runTool(tool, params ?? {})
  res.json(result)
})

app.post('/assistant/chat', async (req, res) => {
  const { text, history = [] } = req.body as {
    text?: string
    history?: Array<{ role: 'user' | 'assistant'; content: string }>
  }

  if (!text?.trim()) return res.status(400).json({ error: 'text is required' })

  if (!(await isRunning())) {
    return res.status(503).json({
      error: 'Ollama is not running. Run setup-athena-agent.command to start it.',
    })
  }

  try {
    const result = await runAssistant(text.trim(), history)
    res.json(result)
  } catch (err) {
    res.status(500).json({
      error: err instanceof Error ? err.message : 'Assistant failed',
    })
  }
})

app.listen(PORT, () => {
  console.log(`Athena Agent listening on http://localhost:${PORT}`)
  console.log(`Model: ${getModel()} | Ollama: http://localhost:11434`)
})
