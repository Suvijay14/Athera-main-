#!/bin/bash
# Double-click this file in Finder to install and start the Athena local agent.
cd "$(dirname "$0")"
chmod +x scripts/install.sh
./scripts/install.sh
