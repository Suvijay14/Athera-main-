#!/bin/bash
# Builds Athena Setup.app and zips for web download
set -euo pipefail

MAC_DIR="$(cd "$(dirname "$0")" && pwd)"
AGENT_DIR="$(cd "$MAC_DIR/.." && pwd)"
APP_NAME="Athena Setup.app"
APP_PATH="$AGENT_DIR/$APP_NAME"
WEB_ZIP="$AGENT_DIR/../athena-web/public/downloads/AthenaAgentSetup.zip"

rm -rf "$APP_PATH"
mkdir -p "$APP_PATH/Contents/MacOS"
mkdir -p "$APP_PATH/Contents/Resources"

cp "$MAC_DIR/Info.plist" "$APP_PATH/Contents/Info.plist"
cp "$MAC_DIR/launcher.sh" "$APP_PATH/Contents/MacOS/launcher"
chmod +x "$APP_PATH/Contents/MacOS/launcher"

# Simple icon: use system mic emoji via AppleScript-generated icns substitute — skip for MVP
# App runs without custom icon (generic app icon)

chmod +x "$AGENT_DIR/scripts/install-core.sh"
chmod +x "$AGENT_DIR/scripts/start-background.sh"

mkdir -p "$(dirname "$WEB_ZIP")"
rm -f "$WEB_ZIP"

# Zip agent folder including the .app (exclude node_modules)
cd "$(dirname "$AGENT_DIR")"
zip -r "$WEB_ZIP" "$(basename "$AGENT_DIR")" \
  -x "$(basename "$AGENT_DIR")/node_modules/*" \
  -x "$(basename "$AGENT_DIR")/.git/*" \
  -x "*.DS_Store"

echo "Built: $APP_PATH"
echo "Zip:   $WEB_ZIP"
echo "Size:  $(du -h "$WEB_ZIP" | cut -f1)"
