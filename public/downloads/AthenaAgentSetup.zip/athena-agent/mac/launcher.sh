#!/bin/bash
# Athena Setup.app — double-click installer (no Terminal needed)

set -euo pipefail

# .../athena-agent/Athena Setup.app/Contents/MacOS/launcher
APP_BUNDLE="$(cd "$(dirname "$0")/../.." && pwd)"
AGENT_DIR="$(cd "$(dirname "$0")/../../.." && pwd)"
SCRIPT_DIR="$AGENT_DIR/scripts"

# Clear Gatekeeper quarantine after download (so double-click works)
xattr -cr "$APP_BUNDLE" 2>/dev/null || true
xattr -cr "$AGENT_DIR" 2>/dev/null || true

alert() {
  osascript -e "display alert \"Athena Setup\" message \"$1\" as informational"
}

confirm() {
  osascript -e "display dialog \"$1\" with title \"Athena Setup\" buttons {\"Cancel\", \"Continue\"} default button \"Continue\"" >/dev/null 2>&1
}

open_settings() {
  open "$1" 2>/dev/null || true
}

# ── Welcome ──
confirm "Welcome to Athena Voice.

This will:
• Install the local AI agent
• Start Ollama (llama3.1:8b)
• Guide you through macOS permissions

Click Continue to begin."

# ── Node.js ──
if ! command -v node >/dev/null 2>&1; then
  alert "Node.js is required. Install it from nodejs.org, then run Athena Setup again."
  open "https://nodejs.org"
  exit 1
fi

# ── Ollama ──
if [ ! -d "/Applications/Ollama.app" ] && ! command -v ollama >/dev/null 2>&1; then
  confirm "Ollama is not installed. It runs the AI model locally.

Click Continue to open ollama.com — install Ollama, then run Athena Setup again."
  open "https://ollama.com/download"
  exit 1
fi

# ── Microphone (browser) ──
confirm "Microphone access is granted in your browser when you click the Voice button in Athena (Chrome recommended).

Click Continue for the next permission."

# ── Screen Recording ──
confirm "Screen Recording lets Athena take screenshots.

System Settings will open. Enable Screen Recording for \"Athena Setup\" (this app).

Click Continue to open Settings."
open_settings "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture"

# ── Files & Folders ──
confirm "Files & Folders lets Athena read Desktop, Documents, and Downloads.

System Settings will open. Enable access for \"Athena Setup\" if listed.

Click Continue to open Settings."
open_settings "x-apple.systempreferences:com.apple.preference.security?Privacy_FilesAndFolders"

# ── Automation (optional) ──
confirm "Automation (optional) lets Athena open folders in Finder.

You can skip this for now. Click Continue to proceed with install."

# ── Install (progress dialog) ──
osascript <<EOF
display dialog "Installing Athena Agent and downloading the AI model. This may take a few minutes on first run." with title "Athena Setup" buttons {"OK"} giving up after 2
EOF

bash "$SCRIPT_DIR/install-core.sh" || {
  CODE=$?
  if [ "$CODE" -eq 3 ]; then
    alert "Ollama is not running. Open the Ollama app from Applications, then run Athena Setup again."
  else
    alert "Setup failed. Check /tmp/athena-agent-setup.log for details."
  fi
  exit 1
}

bash "$SCRIPT_DIR/start-background.sh"

# ── Test screenshot permission ──
TEST_SHOT="/tmp/athena-perm-test-$$.png"
if /usr/sbin/screencapture -x "$TEST_SHOT" 2>/dev/null; then
  rm -f "$TEST_SHOT"
  PERM_MSG="Screen Recording looks good."
else
  PERM_MSG="Screen Recording may still be off — re-open Settings and enable Athena Setup, then run this app again."
  open_settings "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture"
fi

# ── Done ──
osascript -e "display alert \"Athena is ready\" message \"Voice agent is running on port 3002.

$PERM_MSG

Open the Athena web app and click Voice in the sidebar.\" as informational buttons {\"Open Athena\"} default button \"Open Athena\"" \
  && open "http://localhost:3000" || open "http://localhost:3000"

exit 0
